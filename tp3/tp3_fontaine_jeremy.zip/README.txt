*******************************
******  Jeremy FONTAINE  ******
******  M1S2 info        ******
******  TP3 LABD         ******
******  29/01/2015       ******
*******************************

******************
**  Exercice 1  **
******************

Voir exo1/exo1.xsd
et exo1/exo1.xml pour la validation.

******************
**  Exercice 2  **
******************

---- Question 1 ----

Voir exo2/okaz.xsd

******************
**  Exercice 3  **
******************

---- Question 1 ----

Voir exo3/expression.xsd

******************
**  Exercice 4  **
******************

---- Question 1 ----

Voir exo4/football.xsd

J'ai créé exo4/football2.xsd et exo4/football.xml pour la validation.


